<?php $__env->startSection('section'); ?>

<section class="section section__show_entry">
  <div class="show_entry__container container">
    <div class="show_entry__entry">
        <img class="show_entry__img" src="<?php echo e(asset('/images/blog/'.$entry->image)); ?>">
        <h1><?php echo e($entry->titulo); ?></h1>
        <p><?php echo nl2br(e($entry->texto)); ?>      <p>
      </p>
    </div>
    <?php if(session('tipo')=='user'): ?>
    <a  href="<?php echo e(route('edit_entry',['id' =>$entry->id])); ?>" class="btn2"> Editar</a>
    <a  href="<?php echo e(route('delete_entry',['id' =>$entry->id])); ?>" class="btn2"> Borrar</a>
    <?php endif; ?>
    <div class="show_entry__button">
      <button class="btn2" onclick="location.href='<?php echo e(route('blog')); ?>'">Volver</button>
    </div>
  </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/show_entry.blade.php ENDPATH**/ ?>