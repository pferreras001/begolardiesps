<?php $__env->startSection('section'); ?>

<section class="section login__section">

  <div data-aos="flip-left" class="container login__container">

    <form method="POST" action="<?php echo e(route('session_start')); ?>">
    <?php echo csrf_field(); ?>

    <fieldset class="fieldset fieldset__login">
        <?php if(isset($fail)): ?>
        <span class="errmsg errmsg__login">Nombre de usuario o contraseña incorrectos</span>
        <?php endif; ?>
        
        <?php if(isset($email)): ?>
            <input type="text" name="email" value="<?php echo e($email); ?>"><br>
        <?php else: ?>
            <input type="text" name="email" placeholder="Email"><br>
        <?php endif; ?>
      <input type="password" name="password" placeholder="Contraseña"><br>

      <button type="submit" class="btn2 btn__login">Iniciar sesión</button><br>

      <span><a href="<?php echo e(route('recover_password')); ?>">¿Has olvidado tu contraseña?</a></span>

    </fieldset>

    </form>

  </div>


</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/login.blade.php ENDPATH**/ ?>