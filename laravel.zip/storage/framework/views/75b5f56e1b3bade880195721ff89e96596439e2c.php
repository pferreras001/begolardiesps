<div>
    <!-- Knowing is not enough; we must apply. Being willing is not enough; we must do. - Leonardo da Vinci -->
</div><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardies/resources/views/components/home.blade.php ENDPATH**/ ?>