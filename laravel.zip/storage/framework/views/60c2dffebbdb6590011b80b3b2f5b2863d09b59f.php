<?php $__env->startSection('section'); ?>

<section class="section section__recover_password">
  <div class="recover_password__container container">
    <?php if(isset($fail)): ?>
    <span class="errmsg errmsg__login">*No se ha podido realizar la solicitud, comprueba los datos introducidos</span>
    <?php endif; ?>
    <?php if(isset($hecho)): ?>
    <span class="errmsg errmsg__login">*Ya se ha enviado la solicitud, compruebe su bandeja de correo para las instrucciones de recuperacion</span>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('send_recover')); ?>">
    <?php echo csrf_field(); ?>
      <input type="email" name="email" placeholder="Email"required><br>
      <button type="submit" class="btn2">Recuperar contraseña</button>
    </form>
  </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/recover_password.blade.php ENDPATH**/ ?>