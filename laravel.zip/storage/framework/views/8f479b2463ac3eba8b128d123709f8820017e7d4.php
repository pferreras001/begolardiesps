<section class="section footer">
  <div class="footer__container container">
    <ul>
      <li><a href="https://goo.gl/maps/kUgpNzjzk9sNasoa7">C. Juan Antonio Fernández 6A, 1ºA - 31500 Tudela, Navarra</a></li>
      <li><a href="tel:+34-652-54-04-49">+34 652 54 04 49</a></li>
      <li><a href="mailto:info@begolardiespsicologia.com">info@begolardiespsicologia.com</a></li>
    </ul>
    <a href="<?php echo e(route('inicio')); ?>"><?php require('svg/navbar/logo.svg')?></a>
  </div>
</section><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/components/footer.blade.php ENDPATH**/ ?>