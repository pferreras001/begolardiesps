<?php $__env->startSection('section'); ?>

<section class="section section__home">

  <?php if (isset($component)) { $__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Contacto::class, []); ?>
<?php $component->withName('contacto'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6)): ?>
<?php $component = $__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6; ?>
<?php unset($__componentOriginalac09fc5c9794ad2f40fead9f67b9d4b6a29498e6); ?>
<?php endif; ?>

</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/contacto.blade.php ENDPATH**/ ?>