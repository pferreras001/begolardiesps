<!DOCTYPE html>
<htlm lang="es">
<head>
    <meta charset="utf-8">
    <h1>Recuperacion de contraseñas</h1>
</head>
<body>
    <p>Para recuperar su contraseña, haga clic en el siguiente enlace </p>
    <div>
        https://begolardiespsicologia/recover_form/<?php echo e($code); ?>

    </div>
</body>
</htlm><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/recuperacion.blade.php ENDPATH**/ ?>