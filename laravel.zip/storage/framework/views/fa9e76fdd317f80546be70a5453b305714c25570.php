<?php $__env->startSection('section'); ?>

<section class="section section__home">

  <?php if (isset($component)) { $__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Home::class, []); ?>
<?php $component->withName('home'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73)): ?>
<?php $component = $__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73; ?>
<?php unset($__componentOriginal42fcf4fee084002fda68648e3d9e7bc1c1cb3d73); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.lo_que_hago','data' => []]); ?>
<?php $component->withName('lo_que_hago'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal1f95ed42219202295a22d14244efcbd2676e4f0c = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Servicios::class, []); ?>
<?php $component->withName('servicios'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1f95ed42219202295a22d14244efcbd2676e4f0c)): ?>
<?php $component = $__componentOriginal1f95ed42219202295a22d14244efcbd2676e4f0c; ?>
<?php unset($__componentOriginal1f95ed42219202295a22d14244efcbd2676e4f0c); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.sobre_mi','data' => []]); ?>
<?php $component->withName('sobre_mi'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
  <?php if (isset($component)) { $__componentOriginal2c868306deeb13d15ae422e58bc123d9508ee472 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Tarifas::class, []); ?>
<?php $component->withName('tarifas'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2c868306deeb13d15ae422e58bc123d9508ee472)): ?>
<?php $component = $__componentOriginal2c868306deeb13d15ae422e58bc123d9508ee472; ?>
<?php unset($__componentOriginal2c868306deeb13d15ae422e58bc123d9508ee472); ?>
<?php endif; ?>
  <section class="secrtion blog">
    <div class="blog__container container">
      <h1 class="blog__title">Blog.</h1>
      <div class="blog__noticias">
        <?php $__currentLoopData = $blogentrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div data-aos="fade-up" class="blog__box" style="background: url('<?php echo e(asset('/images/blog/'.$blogentry->image)); ?>') no-repeat right;">
          <h2><?php echo e($blogentry->titulo); ?></h2>
          <p><?php echo e($blogentry->texto); ?></p>
          <a class="btn2" href="<?php echo e(route('show_entry',['id' =>$blogentry->id])); ?>">Leer mas...</a>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div style="width: 100%;"></div>
      </div>
    </div>
  </section>

</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/inicio.blade.php ENDPATH**/ ?>