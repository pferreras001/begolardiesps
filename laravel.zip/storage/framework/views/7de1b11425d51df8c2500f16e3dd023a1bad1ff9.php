<?php $__env->startSection('section'); ?>

<section class="section section__edit_entry">    
    <div class="edit_entry__container container">
        <form action="<?php echo e(route('update_entry')); ?>" enctype="multipart/form-data" method="POST">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" value="<?php echo e($entry->id); ?>"/>
            Título<br>
            <input type="text" name="titulo" value="<?php echo e($entry->titulo); ?>"/><br><br>
            Texto<br> 
            <textarea name="texto"><?php echo e($entry->texto); ?></textarea><br><br>
            Selecciona una nueva imagen en caso de desear modificarla<br><input type="file" name="imagen" accept="image/*"/><br><br>
            Etiquetas<br>
            <input type="text" name="etiquetas" value="<?php echo e($entry->etiquetas); ?>"/><br><br>
            <input class="btn2" type="submit" value="Modificar"/> 
        </form>
    </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/edit_entry.blade.php ENDPATH**/ ?>