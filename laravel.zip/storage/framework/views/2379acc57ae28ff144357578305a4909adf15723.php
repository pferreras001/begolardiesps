<?php $__env->startSection('section'); ?>

<section class="section contacto_enviado__section" style="height: 100vh;">
  <div class="contacto_enviado__container container">
    <h1 style="margin-top: 100px;color:#A2A0A0">¡El mensaje ha sido enviado!</h1>
    <a class="btn2" href="<?php echo e(route('inicio')); ?>">Volver al inicio</a>
  </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/contacto_enviado.blade.php ENDPATH**/ ?>