<?php $__env->startSection('section'); ?>

<section data-aos="fade-right" class="section section__blog">
  <div class="blog__container container">
    <form action="<?php echo e(route('blog')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <select class="btn2" id="etiquetas" name="etiquetas" onchange="this.form.submit()">
          <?php if(isset($data)): ?>
              <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($etiqueta->etiqueta==$data): ?>
                        <option selected="selected"><?php echo e($etiqueta->etiqueta); ?></option>
                    <?php else: ?>
                        <option><?php echo e($etiqueta->etiqueta); ?></option>
                    <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
            <option selected="selected">--escoger categoría--</option>
            <?php $__currentLoopData = $etiquetas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $etiqueta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option><?php echo e($etiqueta->etiqueta); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
      </select>
    </form>

    <div class="blog__noticias">
      <?php $__currentLoopData = $blogentrys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogentry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="blog__box" style="background: url('<?php echo e(asset('/images/blog/'.$blogentry->image)); ?>') no-repeat right;">
        <h2><?php echo e($blogentry->titulo); ?></h2>
        <p><?php echo e($blogentry->texto); ?></p>
        <a class="btn2" href="<?php echo e(route('show_entry',['id' =>$blogentry->id])); ?>">Leer mas...</a>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div style="width: 100%;"></div>
      <?php echo e($blogentrys->links()); ?>

    </div>

    <?php if(session('tipo')=='user'): ?>
      <a href="<?php echo e(route('create_entry')); ?>"><button class="btn2"> Crear Entrada</button></a>
    <?php endif; ?>
  </div>
</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardiesps/resources/views/blog.blade.php ENDPATH**/ ?>