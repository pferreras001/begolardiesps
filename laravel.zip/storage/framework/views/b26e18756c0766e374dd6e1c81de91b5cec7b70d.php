<div>
    <!-- Well begun is half done. - Aristotle -->
</div><?php /**PATH /Users/admin/Documents/web_proyects/laravel/begolardies/resources/views/components/footer.blade.php ENDPATH**/ ?>