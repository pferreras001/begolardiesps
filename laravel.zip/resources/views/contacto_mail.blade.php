<!DOCTYPE html>
<htlm lang="es">
<head>
    <meta charset="utf-8">
    <h1>¡Tienes un nuevo mensaje de contacto de {{$email}}!</h1>
</head>
<body>
    <p>{{$mensaje}}</p>
</body>
</htlm>