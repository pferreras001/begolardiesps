<section class="section home">
  <div data-aos="fade-right" class="home__container container">
    <h1>Psicóloga Tudela, Navarra</h1>
    <h3>Begoña Lardiés, Psicóloga Sanitaria en Tudela y Online</h3>
    <a class="btn1" href="{{ route('contacto') }}">Pide cita</a>
  </div>
</section>