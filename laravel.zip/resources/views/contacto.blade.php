@extends('layout')

@section('section')

<section class="section section__home">

  <x-contacto/>

</section>


@endsection