<!DOCTYPE html>
<htlm lang="es">
<head>
    <meta charset="utf-8">
    <h1>Recuperacion de contraseñas</h1>
</head>
<body>
    <p>Para recuperar su contraseña, haga clic en el siguiente enlace </p>
    <div>
        <a href="https://begolardiespsicologia.com/recover_form/{{$code}}"></a>https://begolardiespsicologia.com/recover_form/{{$code}}
    </div>
</body>
</htlm>